create definer = root@localhost view view_byogfylke as
select `oving11`.`levinfo`.`levby` AS `levby`, `oving11`.`levinfo`.`fylke` AS `fylke`
from `oving11`.`levinfo`;

