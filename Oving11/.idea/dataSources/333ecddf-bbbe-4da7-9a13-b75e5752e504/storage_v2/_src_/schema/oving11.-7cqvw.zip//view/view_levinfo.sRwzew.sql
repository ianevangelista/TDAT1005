create definer = root@localhost view view_levinfo as
select `oving11`.`levinfo_kopi`.`levnr`   AS `levnr`,
       `oving11`.`levinfo_kopi`.`navn`    AS `navn`,
       `oving11`.`levinfo_kopi`.`adresse` AS `adresse`,
       `oving11`.`levinfo_kopi`.`levby`   AS `levby`,
       `oving11`.`levinfo_kopi`.`postnr`  AS `postnr`
from `oving11`.`levinfo_kopi`;

